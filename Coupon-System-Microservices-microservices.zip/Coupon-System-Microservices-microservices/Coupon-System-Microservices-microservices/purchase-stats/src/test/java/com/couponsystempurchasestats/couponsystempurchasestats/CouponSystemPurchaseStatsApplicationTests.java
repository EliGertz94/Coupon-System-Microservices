package com.couponsystempurchasestats.couponsystempurchasestats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponSystemPurchaseStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
