package com.coupons.couponsystem.model;

public enum Category {
    FOOD,
    Electricity,
    Restaurant,
    Vacation;
}
