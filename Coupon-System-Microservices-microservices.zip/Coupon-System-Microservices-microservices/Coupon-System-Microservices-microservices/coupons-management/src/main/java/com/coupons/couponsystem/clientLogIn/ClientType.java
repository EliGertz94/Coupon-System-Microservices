package com.coupons.couponsystem.clientLogIn;

public enum ClientType {
    Administrator,
    Company,
    Customer
}
