package com.coupons.couponsystem.model;

public enum Role {

    Administrator,
    Company,
    Customer

}
