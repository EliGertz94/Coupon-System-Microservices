package com.coupons.couponsystem.security;

public class SecurityConstants {

    public static final long JWT_EXPIRATION =700000;
    public static final String JWT_SECRET = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";
}
