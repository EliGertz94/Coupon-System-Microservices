package com.userstats.userdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
